#pragma once

void jolt_initialize();

void jolt_deinitialize();
